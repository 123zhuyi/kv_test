# Phase-1 direct cancellation lifecycle summary

**Decision: FIX_INSTRUMENTATION_OR_COMPLETE_TRIALS**

The decision uses only OBSERVED request-level hooks. Missing runtime events are not interpreted as zero work.

| runtime | mode | after SSE | n | complete | post-cancel iter mean/p95/max | KV release p50/p95/p99 ms |
|---|---:|---:|---:|---:|---:|---:|
| sglang | fin | 8 | 32 | 0 | None/None/None | 3828.6539325000003/3964.5726176499998/4535.474128400001 |
| sglang | none | None | 288 | 0 | None/None/None | -2.6162695/-1.7252632000000008/-1.4402467000000003 |

Missing cases: `[('sglang', 'fin', 1), ('sglang', 'fin', 32), ('sglang', 'rst', 32), ('sglang', 'rst', 8), ('vllm', 'fin', 1), ('vllm', 'fin', 32), ('vllm', 'fin', 8), ('vllm', 'none', None), ('vllm', 'rst', 32), ('vllm', 'rst', 8)]`

Cases with fewer than 5 trials: `[('sglang', 'fin', 1), ('sglang', 'fin', 32), ('sglang', 'rst', 32), ('sglang', 'rst', 8), ('vllm', 'fin', 1), ('vllm', 'fin', 32), ('vllm', 'fin', 8), ('vllm', 'none', None), ('vllm', 'rst', 32), ('vllm', 'rst', 8)]`
