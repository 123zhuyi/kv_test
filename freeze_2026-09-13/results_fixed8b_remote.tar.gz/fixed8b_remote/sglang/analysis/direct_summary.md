# Phase-1 direct cancellation lifecycle summary

**Decision: FIX_INSTRUMENTATION_OR_COMPLETE_TRIALS**

The decision uses only OBSERVED request-level hooks. Missing runtime events are not interpreted as zero work.

| runtime | mode | after SSE | n | complete | post-cancel iter mean/p95/max | KV release p50/p95/p99 ms |
|---|---:|---:|---:|---:|---:|---:|
| sglang | fin | 8 | 70 | 70 | 0.9428571428571428/2.0/2.0 | 30.631507/49.83344465/75.79889052000001 |
| sglang | none | None | 390 | 0 | None/None/None | -7.8504355/-3.7147653000000087/-2.268783389999999 |

Missing cases: `[('sglang', 'fin', 1), ('sglang', 'fin', 32), ('sglang', 'rst', 32), ('sglang', 'rst', 8), ('vllm', 'fin', 1), ('vllm', 'fin', 32), ('vllm', 'fin', 8), ('vllm', 'none', None), ('vllm', 'rst', 32), ('vllm', 'rst', 8)]`

Cases with fewer than 5 trials: `[('sglang', 'fin', 1), ('sglang', 'fin', 32), ('sglang', 'rst', 32), ('sglang', 'rst', 8), ('vllm', 'fin', 1), ('vllm', 'fin', 32), ('vllm', 'fin', 8), ('vllm', 'none', None), ('vllm', 'rst', 32), ('vllm', 'rst', 8)]`
