# Phase-1 direct cancellation lifecycle summary

**Decision: FIX_INSTRUMENTATION_OR_COMPLETE_TRIALS**

The decision uses only OBSERVED request-level hooks. Missing runtime events are not interpreted as zero work.

| runtime | mode | after SSE | n | complete | post-cancel iter mean/p95/max | KV release p50/p95/p99 ms |
|---|---:|---:|---:|---:|---:|---:|
| sglang | fin | 1 | 5 | 0 | None/None/None | 16053.218947/16174.6906012/16181.60037384 |
| sglang | fin | 32 | 5 | 0 | None/None/None | 15803.657485/15803.657485/15803.657485 |
| sglang | fin | 8 | 5 | 0 | None/None/None | 16098.329508/16146.3576726/16152.79430252 |
| sglang | none | None | 5 | 0 | None/None/None | -2.732604/-2.6347869999999998/-2.6229101999999997 |
| sglang | rst | 32 | 5 | 0 | None/None/None | None/None/None |
| sglang | rst | 8 | 5 | 0 | None/None/None | None/None/None |
| sglang | unknown | None | 30 | 0 | None/None/None | 15787.688516/16045.0914882/16088.59502724 |

Missing cases: `[('vllm', 'fin', 1), ('vllm', 'fin', 32), ('vllm', 'fin', 8), ('vllm', 'none', None), ('vllm', 'rst', 32), ('vllm', 'rst', 8)]`

Cases with fewer than 5 trials: `[('vllm', 'fin', 1), ('vllm', 'fin', 32), ('vllm', 'fin', 8), ('vllm', 'none', None), ('vllm', 'rst', 32), ('vllm', 'rst', 8)]`
