# Phase-1 direct cancellation lifecycle summary

**Decision: FIX_INSTRUMENTATION_OR_COMPLETE_TRIALS**

The decision uses only OBSERVED request-level hooks. Missing runtime events are not interpreted as zero work.

| runtime | mode | after SSE | n | complete | post-cancel iter mean/p95/max | KV release p50/p95/p99 ms |
|---|---:|---:|---:|---:|---:|---:|
| sglang | fin | 8 | 57 | 0 | None/None/None | 10613.236783/10912.1244794/10965.59624128 |
| sglang | none | None | 503 | 0 | None/None/None | -5.842633/-2.6238500000000005/-1.9571084199999995 |

Missing cases: `[('sglang', 'fin', 1), ('sglang', 'fin', 32), ('sglang', 'rst', 32), ('sglang', 'rst', 8), ('vllm', 'fin', 1), ('vllm', 'fin', 32), ('vllm', 'fin', 8), ('vllm', 'none', None), ('vllm', 'rst', 32), ('vllm', 'rst', 8)]`

Cases with fewer than 5 trials: `[('sglang', 'fin', 1), ('sglang', 'fin', 32), ('sglang', 'rst', 32), ('sglang', 'rst', 8), ('vllm', 'fin', 1), ('vllm', 'fin', 32), ('vllm', 'fin', 8), ('vllm', 'none', None), ('vllm', 'rst', 32), ('vllm', 'rst', 8)]`
