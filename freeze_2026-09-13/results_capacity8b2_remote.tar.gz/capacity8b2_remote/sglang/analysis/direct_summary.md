# Phase-1 direct cancellation lifecycle summary

**Decision: FIX_INSTRUMENTATION_OR_COMPLETE_TRIALS**

The decision uses only OBSERVED request-level hooks. Missing runtime events are not interpreted as zero work.

| runtime | mode | after SSE | n | complete | post-cancel iter mean/p95/max | KV release p50/p95/p99 ms |
|---|---:|---:|---:|---:|---:|---:|
| sglang | fin | 8 | 70 | 0 | None/None/None | 11263.289395/11558.8070719/11571.678310239999 |
| sglang | none | None | 570 | 0 | None/None/None | -8.0529815/-3.2315167000000007/-1.9841472700000162 |

Missing cases: `[('sglang', 'fin', 1), ('sglang', 'fin', 32), ('sglang', 'rst', 32), ('sglang', 'rst', 8), ('vllm', 'fin', 1), ('vllm', 'fin', 32), ('vllm', 'fin', 8), ('vllm', 'none', None), ('vllm', 'rst', 32), ('vllm', 'rst', 8)]`

Cases with fewer than 5 trials: `[('sglang', 'fin', 1), ('sglang', 'fin', 32), ('sglang', 'rst', 32), ('sglang', 'rst', 8), ('vllm', 'fin', 1), ('vllm', 'fin', 32), ('vllm', 'fin', 8), ('vllm', 'none', None), ('vllm', 'rst', 32), ('vllm', 'rst', 8)]`
